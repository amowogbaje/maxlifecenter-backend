<tr style="vertical-align: middle">
    <td style="padding-top: 24px;padding-bottom: 24px;border-top: 1px solid #d9d9d9;">
        <table role="presentation" cellpadding="0" cellspacing="0" style="width: 100%; margin-top: 0px;">
            <tr>
                <td align="center">
                    <table role="presentation" cellpadding="0" cellspacing="0" style="border-collapse: collapse;">
                        <tr>
                            <td align="center" style="padding: 0 1px;">
                                <a href="#" style="display: inline-block; padding: 6px 2px; text-decoration: none;">
                                    <img src="https://dayout.app/images/app-store.png" alt="Play Store" style="width: 169px;">
                                </a>
                            </td>
                            <td align="center" style="padding: 0 1px;">
                                <a href="#" style="display: inline-block; padding: 6px 2px; text-decoration: none;">
                                    <img src="https://dayout.app/images/play-store.png" alt="Play Store" style="width: 169px;">
                                </a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

        </table>
    </td>
</tr>

<tr>
    <td style="padding-top: 24px;;padding-bottom: 24px;  text-align: center; border-top: 1px solid #d9d9d9;">
        <div style="margin-top: 0px;">
            <a href="https://x.com/joindayout" style="display: inline-block; margin: 0 8px;"><img src="https://dayout.app/images/twitter_icon.png" alt="Social Icon" style="width: 17px; height: 17px;"></a>
            <a href="https://www.linkedin.com/company/join-dayout/" style="display: inline-block; margin: 0 8px;"><img src="https://dayout.app/images/linkedin_icon.png" alt="LinkedIn" style="width: 17px; height: 17px;"></a>
            <a href="https://www.instagram.com/joindayout/" style="display: inline-block; margin: 0 8px;"><img src="https://dayout.app/images/instagram_icon.png" alt="Instagram" style="width: 17px; height: 17px;"></a>
        </div>
    </td>
</tr>

<tr>
    <td style="padding-top: 24px; text-align: center; border-top: 1px solid #d9d9d9;">
        <p style="margin: 24px 0 0 0; font-size: 10px; color: #222222; text-align: center">© {{date('Y')}} Dayout. All rights reserved.</p>
        <p style="margin: 24px 0 0 0; font-size: 10px; color: #555555; text-align: center">
            <a href="https://www.joindayout.app/our-story" style="color: #555555; text-decoration: none; margin: 0 5px;"><u>Our Story</u></a>
            <a href="https://www.joindayout.app/contact-us" style="color: #555555; text-decoration: none; margin: 0 5px;"><u>Contact Us</u></a>
            <a href="#" style="color: #555555; text-decoration: none; margin: 0 5px;"><u>Unsubscribe</u></a>
        </p>
    </td>
</tr>
