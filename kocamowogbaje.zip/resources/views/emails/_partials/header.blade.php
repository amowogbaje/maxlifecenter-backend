<tr>
    <td style="padding: 0 8px;">
        <table role="presentation" cellpadding="0" cellspacing="0">
            <tr>
                <td style="height: 42px; vertical-align: bottom;">
                    <img src="{{ url('images/logo.png') }}" alt="{{ env('APP_NAME')}} Logo" style="width: auto; height: 42px; display: block;">
                </td>
                <td style="padding-left: 16px; vertical-align: bottom;">
                    <span style="color: #076464; font-size: 32px; font-weight: 600; line-height: 1.2; font-family: 'Poppins', Arial, sans-serif;">Watchlocker</span>
                </td>
            </tr>
        </table>
    </td>
</tr>
